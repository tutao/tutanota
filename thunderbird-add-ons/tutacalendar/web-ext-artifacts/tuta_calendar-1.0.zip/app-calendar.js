browser.spacesToolbar.addButton("tutacalendar", {
	title: "Tuta Calendar",
	defaultIcons: "icon-calendar.svg",
	url: "https://app.tuta.com/calendar/",
})
