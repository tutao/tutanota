browser.spacesToolbar.addButton("tutamail", {
	title: "Tuta Mail",
	defaultIcons: "icon-mail.svg",
	url: "https://app.tuta.com/mail/",
})
